# Rattrapage-Web
Lien Github : https://github.com/G2ll0u/Rattrapage
Il faut mettre le site dans un dossier "StockFlow" qui se trouve dans la racine du localhost (nommé "localhost")
Pour hash les données (dans le cadre de l'exercice), copiez/collez :
http://localhost/Rattrapage/update_passwords.php
