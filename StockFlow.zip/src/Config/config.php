<?php
// Définit l'URL de base du site 
define('BASE_URL', 'http://localhost/StockFlow/');
?>