<?php
namespace App\Controller;

use App\Models\ProductModel;
use App\Models\CategoryModel;

class ProductController extends Controller {
    private $productModel;
    private $categoryModel;
    
    public function __construct() {
        parent::__construct();
        $this->productModel = new ProductModel();
        $this->categoryModel = new CategoryModel();
    }
    
    /**
     * Page principale - Liste des produits avec filtrage simple
     */
    public function index() {
        $this->checkAuth();
     
        // Récupération des paramètres
        $search = $_GET['search'] ?? '';
        $category = $_GET['category'] ?? '';
        $sort = $_GET['sort'] ?? 'name';
        $direction = $_GET['direction'] ?? 'asc';
        
        // Récupération des données
        $categories = $this->categoryModel->getAllCategories();
        $products = $this->getFilteredProducts($search, $category);
        
        // Gestion du tri
        $products = $this->sortProducts($products, $sort, $direction);
        
        // Préparation des données pour l'affichage
        $categoryNames = [];
        foreach ($categories as $cat) {
            $categoryNames[$cat->ID_Category] = $cat->name;
        }
        
        // Gestion des produits à faible stock
        $lowStockProducts = array_filter($products, function($product) {
            return $product->amount <= $product->alert_threshold;
        });
        
        // Rendu de la vue
        $this->render('product/index.twig', [
            'products' => $products,
            'categories' => $categories,
            'categoryNames' => $categoryNames,
            'search' => $search,
            'selectedCategory' => $category,
            'sort' => $sort,
            'direction' => $direction,
            'lowStockCount' => count($lowStockProducts),
            'page_title' => 'Liste des produits'
        ]);
    }

    /**
     * Page dédiée à la gestion CRUD des produits
     */
    public function manage() {
        $this->checkAuth();
     
        // Récupération des paramètres
        $action = $_GET['action'] ?? 'list';
        $id = $_GET['id'] ?? null;
        $search = $_GET['search'] ?? '';
        $category = $_GET['category'] ?? '';
        $sort = $_GET['sort'] ?? 'name';
        $direction = $_GET['direction'] ?? 'asc';
        
        // Initialisation des données pour les notifications
        $notification = [
            'type' => '',
            'title' => '',
            'message' => '',
            'show' => false
        ];
        
        // Récupération des données
        $categories = $this->categoryModel->getAllCategories();
        $products = $this->getFilteredProducts($search, $category);
        
        // Gestion du tri
        $products = $this->sortProducts($products, $sort, $direction);
        
        // Préparation des données pour l'affichage
        $categoryNames = [];
        foreach ($categories as $cat) {
            $categoryNames[$cat->ID_Category] = $cat->name;
        }
        
        // Gestion des produits à faible stock
        $lowStockProducts = array_filter($products, function($product) {
            return $product->amount <= $product->alert_threshold;
        });
        
        // Traitement des actions CRUD
        $currentProduct = null;
        $errors = [];
        $success = '';
        
        // Récupération du produit si action d'édition ou visualisation
        if (in_array($action, ['edit', 'view', 'delete']) && $id) {
            $currentProduct = $this->productModel->getProduct($id);
            if (!$currentProduct) {
                $action = 'list';
                $notification = [
                    'type' => 'danger',
                    'title' => 'Erreur',
                    'message' => 'Produit introuvable',
                    'show' => true
                ];
            }
        }
        
        // Traitement des soumissions de formulaire
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (isset($_POST['action'])) {
                switch ($_POST['action']) {
                    case 'create':
                        [$success, $errors] = $this->handleCreate();
                        if (empty($errors)) {
                            $notification = [
                                'type' => 'success',
                                'title' => 'Succès',
                                'message' => $success,
                                'show' => true
                            ];
                        } else {
                            $notification = [
                                'type' => 'danger',
                                'title' => 'Erreur',
                                'message' => implode(', ', $errors),
                                'show' => true
                            ];
                        }
                        break;
                        
                    case 'update':
                        [$success, $errors, $currentProduct] = $this->handleUpdate();
                        if (empty($errors)) {
                            $notification = [
                                'type' => 'success',
                                'title' => 'Succès',
                                'message' => $success,
                                'show' => true
                            ];
                        } else {
                            $notification = [
                                'type' => 'danger',
                                'title' => 'Erreur',
                                'message' => implode(', ', $errors),
                                'show' => true
                            ];
                        }
                        break;
                        
                    case 'delete':
                        [$success, $errors] = $this->handleDelete();
                        if (empty($errors)) {
                            $notification = [
                                'type' => 'success',
                                'title' => 'Succès',
                                'message' => $success,
                                'show' => true
                            ];
                        } else {
                            $notification = [
                                'type' => 'danger',
                                'title' => 'Erreur',
                                'message' => implode(', ', $errors),
                                'show' => true
                            ];
                        }
                        $action = 'list'; // Retour à la liste après suppression
                        break;
                }
                
                // Si aucune erreur, actualiser la liste des produits
                if (empty($errors)) {
                    $products = $this->getFilteredProducts($search, $category);
                    $products = $this->sortProducts($products, $sort, $direction);
                }
            }
        }
        
        // Notification pour la recherche de produits si applicable
        if (!empty($search) || !empty($category)) {
            $count = count($products);
            if ($count > 0 && $notification['type'] === '') {
                $notification = [
                    'type' => 'info',
                    'title' => 'Recherche',
                    'message' => "Votre recherche a retourné $count produit(s)",
                    'show' => true
                ];
            } else if ($notification['type'] === '') {
                $notification = [
                    'type' => 'warning',
                    'title' => 'Recherche',
                    'message' => "Aucun produit trouvé pour votre recherche",
                    'show' => true
                ];
            }
        }
        
        // Rendu de la vue
        $this->render('product/manage.twig', [
            'action' => $action,
            'products' => $products,
            'categories' => $categories,
            'categoryNames' => $categoryNames,
            'currentProduct' => $currentProduct,
            'search' => $search,
            'selectedCategory' => $category,
            'sort' => $sort,
            'direction' => $direction,
            'lowStockCount' => count($lowStockProducts),
            'errors' => $errors,
            'success' => $success,
            'notification' => $notification,
            'isAdmin' => isset($_SESSION['user']['role']) && $_SESSION['user']['role'] === 'Admin',
            'isManager' => isset($_SESSION['user']['role']) && ($_SESSION['user']['role'] === 'Manager' || $_SESSION['user']['role'] === 'Admin'),
            'page_title' => 'Gestion des produits'
        ]);
    }

    /**
     * Affiche le formulaire de création d'un produit
     */
    public function create() {
        $this->checkAuth();
        
        // Vérification des permissions
        if (!isset($_SESSION['user']['role']) || !in_array($_SESSION['user']['role'], ['Admin', 'Manager'])) {
            $this->redirect('product', 'index');
            return;
        }
        
        $categories = $this->categoryModel->getAllCategories();
        
        $this->render('product/create.twig', [
            'categories' => $categories,
            'page_title' => 'Ajouter un nouveau produit'
        ]);
    }
    
    /**
     * Affiche la page détaillée d'un produit
     */
    public function view($id = null) {
        $this->checkAuth();
        
        if (!$id) {
            $id = $_GET['id'] ?? null;
        }
        
        if (!$id) {
            $this->redirect('product', 'index');
            return;
        }
        
        $product = $this->productModel->getProduct($id);
        if (!$product) {
            $this->redirect('product', 'index');
            return;
        }
        
        $category = $this->categoryModel->getCategory($product->ID_Category);
        
        $this->render('product/view.twig', [
            'product' => $product,
            'category' => $category,
            'page_title' => 'Détails du produit: ' . $product->name
        ]);
    }
    
    /**
     * Traite la création d'un nouveau produit
     * @return array [message de succès, erreurs]
     */
    private function handleCreate() {
        $errors = [];
        
        // Validation des données
        $reference = $_POST['reference'] ?? '';
        $name = $_POST['name'] ?? '';
        $amount = intval($_POST['amount'] ?? 0);
        $price = floatval($_POST['price'] ?? 0);
        $last_delivery = !empty($_POST['last_delivery']) ? $_POST['last_delivery'] : date('Y-m-d');
        $alert_threshold = intval($_POST['alert_threshold'] ?? 0);
        $ID_Category = intval($_POST['ID_Category'] ?? 0);
        
        // Vérifications basiques
        if (empty($reference)) {
            $errors[] = "La référence est obligatoire";
        }
        if (empty($name)) {
            $errors[] = "Le nom est obligatoire";
        }
        if ($price <= 0) {
            $errors[] = "Le prix doit être supérieur à 0";
        }
        if ($ID_Category <= 0) {
            $errors[] = "Veuillez sélectionner une catégorie";
        }
        
        // Si aucune erreur, créer le produit
        if (empty($errors)) {
            $success = $this->productModel->createProduct(
                $reference, $name, $amount, $price, $last_delivery, 
                $alert_threshold, $ID_Category
            );
            
            if ($success) {
                return ["Produit \"$name\" ajouté avec succès", []];
            } else {
                return ["", ["Erreur lors de l'ajout du produit"]];
            }
        }
        
        return ["", $errors];
    }
    
    /**
     * Traite la mise à jour d'un produit
     * @return array [message de succès, erreurs, produit mise à jour]
     */
    private function handleUpdate() {
        $errors = [];
        $id = $_POST['id'] ?? null;
        
        if (!$id) {
            return ["", ["ID du produit manquant"], null];
        }
        
        // Récupération du produit existant
        $product = $this->productModel->getProduct($id);
        if (!$product) {
            return ["", ["Produit introuvable"], null];
        }
        
        // Validation des données
        $reference = $_POST['reference'] ?? '';
        $name = $_POST['name'] ?? '';
        $amount = intval($_POST['amount'] ?? 0);
        $price = floatval($_POST['price'] ?? 0);
        $last_delivery = !empty($_POST['last_delivery']) ? $_POST['last_delivery'] : date('Y-m-d');
        $alert_threshold = intval($_POST['alert_threshold'] ?? 0);
        $ID_Category = intval($_POST['ID_Category'] ?? 0);
        
        // Vérifications basiques
        if (empty($reference)) {
            $errors[] = "La référence est obligatoire";
        }
        if (empty($name)) {
            $errors[] = "Le nom est obligatoire";
        }
        if ($price <= 0) {
            $errors[] = "Le prix doit être supérieur à 0";
        }
        if ($ID_Category <= 0) {
            $errors[] = "Veuillez sélectionner une catégorie";
        }
        
        // Si aucune erreur, mettre à jour le produit
        if (empty($errors)) {
            $success = $this->productModel->updateProduct(
                $id, $reference, $name, $amount, $price, 
                $last_delivery, $alert_threshold, $ID_Category
            );
            
            if ($success) {
                $updatedProduct = $this->productModel->getProduct($id);
                return ["Produit \"$name\" mis à jour avec succès", [], $updatedProduct];
            } else {
                return ["", ["Erreur lors de la mise à jour du produit"], $product];
            }
        }
        
        return ["", $errors, $product];
    }
    
    /**
     * Traite la suppression d'un produit
     * @return array [message de succès, erreurs]
     */
    private function handleDelete() {
        // Vérification des droits d'administrateur
        if (!isset($_SESSION['user']['role']) || $_SESSION['user']['role'] !== 'Admin') {
            return ["", ["Vous n'avez pas les droits nécessaires pour supprimer un produit"]];
        }
        
        $id = $_POST['id'] ?? null;
        
        if (!$id) {
            return ["", ["ID du produit manquant"]];
        }
        
        $product = $this->productModel->getProduct($id);
        if (!$product) {
            return ["", ["Produit introuvable"]];
        }
        
        $name = $product->name;
        $success = $this->productModel->deleteProduct($id);
        
        if ($success) {
            return ["Produit \"$name\" supprimé avec succès", []];
        } else {
            return ["", ["Erreur lors de la suppression du produit"]];
        }
    }
    
    /**
     * Récupère les produits filtrés
     */
    private function getFilteredProducts($search, $category) {
        if (!empty($search)) {
            $products = $this->productModel->getFilteredProduct($search);
        } else {
            $products = $this->productModel->getAllProducts();
        }
        
        if (!empty($category)) {
            $products = array_filter($products, function($product) use ($category) {
                return $product->ID_Category == $category;
            });
        }
        
        return $products;
    }
    
    /**
     * Trie les produits selon les critères
     */
    private function sortProducts($products, $sort, $direction) {
        usort($products, function($a, $b) use ($sort, $direction) {
            if ($direction === 'asc') {
                return $a->$sort <=> $b->$sort;
            } else {
                return $b->$sort <=> $a->$sort;
            }
        });
        
        return $products;
    }
}